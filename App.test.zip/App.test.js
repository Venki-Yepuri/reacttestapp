import { render, screen, fireEvent, waitForElement } from '@testing-library/react';
import App, { url } from './App';
import samplejson from './samplejson';

import axios from "axios";

let url1 = url;
let body = {}


/*jest.mock("axios", () => ({
  get: jest.fn((_url1, _body) => {
    url = _url1;
    body = _body;
    return Promise.resolve();
  })
}));*/

describe('59892259', () => {

  render(<App />);
  // let originFetch;
  /* beforeEach(() => {
     originFetch = (global).fetch;
   });
   afterEach(() => {
     (global).fetch = originFetch;
   });*/

  /* test('renders learn react link', () => {
     //render(<App />);
     const linkElement = screen.getByText(/Click me/i);
     expect(linkElement).toBeInTheDocument();
   });
   test('before click event', () => {
     //render(<App />);
     const linkElement1 = screen.getByText(/You clicked 0 times/i);
     expect(linkElement1).toBeInTheDocument();
   });*/
  test('after click event', async () => {
    //render(<App />);
    /*const fakeResponse = { samplejson };
    const mRes = { json: jest.fn().mockResolvedValueOnce(fakeResponse) };
    const mockedFetch = jest.fn().mockResolvedValueOnce(mRes);
    (global).fetch = mockedFetch;
    const { getByTestId } = render(<App/>);
    const div = await waitForElement(() => getByTestId('test'));
    expect(div).toHaveTextContent(samplejson);
    expect(mockedFetch).toBeCalledTimes(1);
    expect(mRes.json).toBeCalledTimes(1);*/
    // const fakeResponse = { samplejson };
    jest.mock('axios', () => {
      return {
        __esModule: true,
        default: jest.fn()
      }
    });
   // const axios = require('axios');
    jest.spyOn(axios, 'default').mockResolvedValue({
      name: 'abc'
    })

    jest.spyOn(axios, 'get').mockImplementationOnce({
      data: 'abc'
    })
   


    /*axios.get.mockResolvedValueOnce(
      {
  
        "data": {
          "hits": [
            {
              "created_at": "2020-05-27T16:05:32.000Z",
              "title": "Guerrilla Public Service Redux (2017)",
              "url": "https://99percentinvisible.org/episode/guerrilla-public-service/",
              "author": "DerWOK",
              "points": 421,
              "story_text": null,
              "comment_text": null,
              "num_comments": 110,
              "story_id": null,
              "story_title": null,
              "story_url": null,
              "parent_id": null,
              "created_at_i": 1590595532,
              "_tags": [
                "story",
                "author_DerWOK",
                "story_23325319"
              ],
              "objectID": "23325319",
              "_highlightResult": {
                "title": {
                  "value": "Guerrilla Public Service \u003cem\u003eRedux\u003c/em\u003e (2017)",
                  "matchLevel": "full",
                  "fullyHighlighted": false,
                  "matchedWords": [
                    "redux"
                  ]
                },
                "url": {
                  "value": "https://99percentinvisible.org/episode/guerrilla-public-service/",
                  "matchLevel": "none",
                  "matchedWords": [
  
                  ]
                },
                "author": {
                  "value": "DerWOK",
                  "matchLevel": "none",
                  "matchedWords": [
  
                  ]
                }
              }
            }]
        }
      }
    );*/

    const { getAllByTestId, getByText } = render(<App />);

    const rowValues = await waitForElement(() =>
      getAllByTestId("li").map(row => row.textContent)
    );

    screen.debug(rowValues);

    //expect(axios.get).toHaveBeenCalledWith(url);
    //expect(axios.get).toHaveBeenCalledTimes(1);

    /* const linkElement = screen.getByText(/Click me/i);
     fireEvent.click(linkElement);
     fireEvent.click(linkElement);
     const linkElement1 = screen.getByText(/You clicked 2 times/i);
     expect(linkElement1).toBeInTheDocument();*/
  });
});
