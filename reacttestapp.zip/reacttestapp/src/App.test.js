import React from 'react';
import { mount, configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import App, { url } from './App';
import { act } from "react-dom/test-utils";
jest.unmock('axios');
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

configure({ adapter: new Adapter() });


//jest.mock("axios");

//axios.mockResolvedValue();

// This sets the mock adapter on the default instance
//var mock = new MockAdapter(axios);
const data = [
    {
        "id": 1,
        "name": "Leanne Graham",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "address": {
            "street": "Kulas Light",
            "suite": "Apt. 556",
            "city": "Gwenborough",
            "zipcode": "92998-3874",
            "geo": {
                "lat": "-37.3159",
                "lng": "81.1496"
            }
        },
        "phone": "1-770-736-8031 x56442",
        "website": "hildegard.org",
        "company": {
            "name": "Romaguera-Crona",
            "catchPhrase": "Multi-layered client-server neural-net",
            "bs": "harness real-time e-markets"
        }
    }]


//const axios = require('axios');

describe('<Login /> with no props', () => {
    let wrapper;
    var mock = new MockAdapter(axios);

    mock.onGet(url).reply(200, data);
    //const container = mount(<App />);
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should match the snapshot', async () => {

        // mock axios promise

        // mock axios promise

        wrapper = mount(<App />);
        wrapper.update();
        console.log(wrapper.debug());
        wrapper.find('button').at(0).simulate('click');
        wrapper.find('button').at(1).simulate('click');
        wrapper.find('button').at(2).simulate('click');
        wrapper.find('button').at(3).simulate('click');
        wrapper.find('button').at(4).simulate('click');
        wrapper.update();
        //expect(wrapper.html()).toBeLessThanOrEqual();
    });

});
