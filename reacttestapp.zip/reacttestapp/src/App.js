import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';
import CountApp from './CountApp';

function App() {
  return (
    <div className="App">
      <CountApp name="John"/>
    </div>
  );
}
export default App;
