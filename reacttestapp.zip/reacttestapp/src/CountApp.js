import React, { useState, useEffect } from 'react';
import axios from 'axios';

export const url = "https://jsonplaceholder.typicode.com/users/";

function CountApp() {
    const [count, setCount] = useState(0);
    const [data, setData] = useState([]);
    const [user, setUser] = useState({});

    useEffect(() => {
        document.title = `You clicked ${count} times`;
      async function fetchData() {
            const result = await axios(
                url,
            );
            setData(result.data);
        }
        fetchData();
    });

    const addUser = () => {
        console.log("addUser");
        
    };
    const getUser = () => {
        console.log("getUser");
        console.log(user);    
        axios.get(`https://jsonplaceholder.typicode.com/users/1`)
            .then(res => {
                const user = res.data;
                setUser( user );
                console.log(user);    
            })
        console.log(user);    
    };
    const updateUser = () => {
        console.log("updateUser");
    };
    const removeUser = () => {
        console.log("removeUser");
    };

    return (
        <div>
            <div>
                <p>You clicked {count} times</p>
                <button onClick={() => setCount(count + 1)}>
                    Click me
                </button>
            </div>
            <div>
                <button onClick={() => addUser()}>
                    addUser
                </button>
            </div>
            <div>
            <p>{user.name}</p>
                <button onClick={() => getUser()}>
                    getUser
                </button>
            </div>
            <div>
                <button onClick={() => updateUser()}>
                    updateUser
                </button>
            </div>
            <div>
                <button onClick={() => removeUser()}>
                    removeUser
                </button>
            </div>
            <div data-testid="test">
                <ul>
                    {data.map(item => (
                        <li key={item.id} data-testid="li" style={{listStyle: "none"}}>
                           {item.name}
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}
export default CountApp;